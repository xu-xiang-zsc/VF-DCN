function [labels, numImagesAll] = computeLabels_builtin_roi_fvusm(path)

    imds = imageDatastore(path,'IncludeSubfolders',true,'LabelSource','none');
    files = string(imds.Files);
    parts = split(files,filesep);
    pp = split(parts(:,end),'_');
    c = [pp(:,1), pp(:,2)];
    labels_name = categorical(join(c,'_'));
    % cc = split(pp(:,end),'.');
    % condition=cc(:,1);
    numImagesAll = numel(files);
    % allIndexes = 1 : numImagesAll;
    classes = unique(labels_name);
    labels = zeros(numImagesAll, 1);
    
    % indImagesTest = zeros(length(labels_name),1);
    % indImagesTrain = zeros(length(labels_name),1);
    for i = 1 : length(classes)
        [ind] = find(labels_name==classes(i));
        labels(ind) = i;    
    end 


