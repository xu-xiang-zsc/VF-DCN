function [indexesFold, allIndexes, indImagesTrain, numImagesTrain] = computeIndexesPersonFold_312(numImagesAll, labels, param)

%indexesFold = personFold(numImagesAll, labels, param.kfold);
indexesFold=ones(6000,1);
indexesFold(3121:end)=2;

indImagesTrain = (indexesFold ~= 1); %1 or 2
indImagesTest = ~indImagesTrain;
allIndexes = 1 : numImagesAll;
% indImagesTrain=zeros(6000,1);
% indImagesTest=zeros(6000,1);
% indImagesTrain(3121:end)=1;
% indImagesTest(1:3120)=1;

numImagesTrain = numel(find(indImagesTrain));
numImagesTest = numel(find(indImagesTest));

