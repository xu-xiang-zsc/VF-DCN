function [ftest_all, numFeatures] = ...
    featExtrGaborAdapt(imagesCellTest, LogGaborNet, bestWavelets, numImagesTest, stepPrint, numCoresFeatExtr)

% one iteration to get size and init
ftest = Gabor_FeaExt(imagesCellTest(1), LogGaborNet, bestWavelets);
numFeatures = size(ftest, 1);

% init feature matrix
ftest_all = sparse(numFeatures, numImagesTest);
ftest_all(:, 1) = ftest;

start_pool(numCoresFeatExtr);

parfor j = 2 : numel(imagesCellTest)
% for j = 2 : numel(imagesCellTest)
    % get id of current worker
    t = getCurrentTask();
    
    % display progress
    if mod(j, stepPrint) == 0
        fprintf(1, ['\t\tCore ' num2str(t.ID) ': ' num2str(j) ' / ' num2str(numImagesTest) '\n']);
    end

    % get image
    im = imagesCellTest(j);
    
    % PCANet output
    ftest = Gabor_FeaExt(im, LogGaborNet, bestWavelets);    
    
    %save descriptor
    ftest_all(:, j) = ftest;    
end



