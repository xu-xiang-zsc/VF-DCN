function gaborResponses = computeGaborResponses(im, gabor)
NumFilters=numel(gabor);
%init
gaborResponses = zeros(size(im,1), size(im,2), NumFilters);
imagefft = fft2(im);  
%figure
for oriIndex = 1 : numel(gabor)
    %oriIndex
    filter = gabor(oriIndex).filter;
        %normalize
    %%%%%%%%%%%%%%%%%%%%%
    %filter = filter ./ max(filter(:));
    %%%%%%%%%%%%%%%%%%%%%
    
    %gaborResponses(:, :, oriIndex) = imfilter(im, filter, 'replicate', 'same', 'conv');
    gaborResponses(:, :, oriIndex)=real(ifft2(imagefft .* filter));
   %  gaborResponses(:, :, oriIndex)=abs(ifft2(imagefft .* filter));
   %subplot(4,4,oriIndex),imshow(gaborResponses(:, :, oriIndex))
end %for oriIndex = 1 : param.divTheta

%figure,montage(gaborResponses)
