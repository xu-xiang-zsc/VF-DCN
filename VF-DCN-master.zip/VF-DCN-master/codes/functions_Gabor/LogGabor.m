function log_filters = LogGabor(imageSize, orient_chosen, nscale)

    rows = imageSize(1);
    cols = imageSize(2);
    norient = length(orient_chosen);

    minWaveLength = 2; 
    mult = 2.2;
    sigmaOnf = 0.55; 
    dThetaOnSigma = 1.3;
    % Notes on filter settings to obtain even coverage of the spectrum energy
    % dThetaOnSigma 1.2 - 1.3
    % sigmaOnf  .90   mult 1.15
    % sigmaOnf  .85   mult 1.2
    % sigmaOnf  .75   mult 1.4       (bandwidth ~1 octave)
    % sigmaOnf  .65   mult 1.7
    % sigmaOnf  .55   mult 2.2       (bandwidth ~2 octaves)
    
    thetaSigma = pi/norient/dThetaOnSigma;    
    
    zero = zeros(rows, cols);

    if mod(cols, 2)
        xrange = (-(cols-1)/2:(cols-1)/2)/(cols-1);
    else
        xrange = (-cols/2:(cols/2-1))/cols; 
    end
    
    if mod(rows, 2)
        yrange = (-(rows-1)/2:(rows-1)/2)/(rows-1);
    else
        yrange = (-rows/2:(rows/2-1))/rows; 
    end
    
    [x, y] = meshgrid(xrange, yrange);
    
    radius = sqrt(x.^2 + y.^2);       % Matrix values contain *normalised* radius from centre.
    theta = atan2(y, x);               % Matrix values contain polar angle.
                                  
    radius = ifftshift(radius);       % Quadrant shift radius and theta so that filters
    theta  = ifftshift(theta);        % are constructed with 0 frequency at the corners.
    radius(1, 1) = 1;                  % Get rid of the 0 radius value at the 0
                                      % frequency point (now at top-left corner)
                                      % so that taking the log of the radius will 
                                      % not cause trouble.
    sintheta = sin(theta);
    costheta = cos(theta);
    clear x; clear y; clear theta;    % save a little memory
    
   
    lp = lowpassfilter([rows,cols], .45, 15);   % Radius .45, 'sharpness' 15

    logGabor = cell(1, nscale);

    for s = 1 : nscale
        wavelength = minWaveLength*mult^(s-1);
        fo = 1.0/wavelength;                  % Centre frequency of filter.
        logGabor{s} = exp((-(log(radius/fo)).^2) / (2 * log(sigmaOnf)^2));  
        logGabor{s} = logGabor{s}.*lp;        % Apply low-pass filter
        logGabor{s}(1,1) = 0;                 % Set the value at the 0
                                              % frequency point of the filter 
                                              % back to zero (undo the radius fudge). 
        shift_log{s} = fftshift(logGabor{s});
    end

    spread = cell(1, norient);

    % The main loop...
    for o = 1 : norient
        angl =orient_chosen(o);           % Filter angle.
        ds = sintheta * cos(angl) - costheta * sin(angl);    % Difference in sine.
        dc = costheta * cos(angl) + sintheta * sin(angl);    % Difference in cosine.
        dtheta = abs(atan2(ds,dc));                          % Absolute angular distance.
        spread{o} = exp((-dtheta.^2) / (2 * thetaSigma^2));  % Calculate the
                                                       % angular filter component.
        shift_spread{o} = fftshift(spread{o});
    end
 
    figure, montage(shift_log), title('scale');
    figure, montage(shift_spread), title('orientation');

    for o = 1 : norient % For each orientation.
        %  fprintf('Processing orientation %d\r',o);   
        for s = 1 : nscale  % For each scale.
            filter = logGabor{s} .* spread{o};   % Multiply radial and angular components to get the filter.
            log_filters{s, o} = filter;
            shift_filters{s, o} = shift_log{s} .* shift_spread{o};
        end
    end
  
    figure, montage(shift_filters);