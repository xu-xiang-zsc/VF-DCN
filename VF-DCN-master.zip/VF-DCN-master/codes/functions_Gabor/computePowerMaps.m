function powerMapF = computePowerMaps(resF, gaborBank)

powerMapF(numel(gaborBank)).value = [];
for g = 1 : numel(gaborBank)
    %powerMapF(g).value = abs(resF(g).filter);
    powerMapF(g).value = abs(real(resF(g).filter));
    %size(powerMapF(g).value);
end %for g = 1 : numel(gaborBank)
