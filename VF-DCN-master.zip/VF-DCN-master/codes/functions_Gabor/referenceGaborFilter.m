function resF = referenceGaborFilter(gaborBank, im)
    % filter image with all filters
    % init
    resF(numel(gaborBank)).filter = [];

    imagefft = fft2(im); 
    for g = 1 : numel(gaborBank)
        % normal filtering
        % filtering according to paper
        filter = gaborBank{g};
        resF(g).filter = ifft2(imagefft .* filter);        
    end