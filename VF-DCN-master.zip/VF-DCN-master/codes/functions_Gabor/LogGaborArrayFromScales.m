function log_filters = LogGaborArrayFromScales(imageSize, thetaVector, nscale, param, plotta)

    log_filters = LogGabor(imageSize, thetaVector, nscale);
