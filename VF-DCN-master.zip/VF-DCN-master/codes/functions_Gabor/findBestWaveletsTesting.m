% function [bestWaveletsAll, PalmNet] = findBestWaveletsTesting(imagesCell, orient_default, orient_best, PalmNet, numImagesToUse, imageSize, param, stepPrint, plotta)
function [bestWaveletsAll, PalmNet] = findBestWaveletsTesting(imagesCell, orient_default, PalmNet, numImagesToUse, imageSize, param, stepPrint, plotta)
%init
bestWaveletsAll(param.numBestWavelets).filter = [];
%--------------------------------------
%Compute parametrized wavelets
%parametrizedWavelets = gaborArrayParametrized( deg2rad(orient_default));
im=imagesCell{1};
[gaborBank_1, gaborBank_2, gaborBank_3, gaborBank_4] =gaborArrayFromScales(imageSize, deg2rad([orient_default]), param, plotta);
gaborResponses_1 = computeGaborResponses(im, gaborBank_1);

%init counter for how many times each wavelet is chosen
%scale=1

gaborBank=gaborBank_1;
o_counterAll = zeros(numel(gaborBank), 1);
parfor j = 1 : numImagesToUse
%for j = 1 : numel(imagesCell)
    %get id of current worker
    t = getCurrentTask();
    %display progress
    if mod(j, stepPrint) == 0
        fprintf(1, ['\t\tCore ' num2str(t.ID) ': ' num2str(j) ' / ' num2str(numImagesToUse) '\n'])
    end %if mod(i, 100) == 0
    %get img
    im = imagesCell{j};
    %--------------------------------------
    %Perform reference Gabor filtering
    %fprintf_pers(fidLogs, '\t\tPerforming reference Gabor filtering... \n')
    resF= referenceGaborFilter(gaborBank, im);
    %--------------------------------------
    %create powerMap for all filters
    %fprintf_pers(fidLogs, '\t\tComputing powermaps... \n')
    powerMapF = computePowerMaps(resF, gaborBank);
    %--------------------------------------
    %Sort filter response information
    %fprintf_pers(fidLogs, '\t\tSorting filter response information... \n')
    [sortRes, sizeRes] = sortFilterResponse(gaborBank, powerMapF);
    %--------------------------------------
    %Compute most used wavelets
    %fprintf_pers(fidLogs, '\t\t\tComputing most used wavelets... \n')
    o_counter = getMostUsedWavelets(sortRes, gaborBank, powerMapF, param, sizeRes, plotta);
    %increment
    o_counterAll = o_counterAll + o_counter;
end %for j = 1 : length(vectorIndexTest)
o_counterAll_1=o_counterAll;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gaborBank=gaborBank_2;
o_counterAll = zeros(numel(gaborBank), 1);
parfor j = 1 : numImagesToUse
%for j = 1 : numel(imagesCell)
    %get id of current worker
    t = getCurrentTask();
    %display progress
    if mod(j, stepPrint) == 0
        fprintf(1, ['\t\tCore ' num2str(t.ID) ': ' num2str(j) ' / ' num2str(numImagesToUse) '\n'])
    end %if mod(i, 100) == 0
    %get img
    im = imagesCell{j};
    %--------------------------------------
    %Perform reference Gabor filtering
    %fprintf_pers(fidLogs, '\t\tPerforming reference Gabor filtering... \n')
    resF= referenceGaborFilter(gaborBank, im);
    %--------------------------------------
    %create powerMap for all filters
    %fprintf_pers(fidLogs, '\t\tComputing powermaps... \n')
    powerMapF = computePowerMaps(resF, gaborBank);
    %--------------------------------------
    %Sort filter response information
    %fprintf_pers(fidLogs, '\t\tSorting filter response information... \n')
    [sortRes, sizeRes] = sortFilterResponse(gaborBank, powerMapF);
    %--------------------------------------
    %Compute most used wavelets
    %fprintf_pers(fidLogs, '\t\t\tComputing most used wavelets... \n')
    o_counter = getMostUsedWavelets(sortRes, gaborBank, powerMapF, param, sizeRes, plotta);
    %increment
    o_counterAll = o_counterAll + o_counter;
end %for j = 1 : length(vectorIndexTest)
o_counterAll_2=o_counterAll;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gaborBank=gaborBank_3;
o_counterAll = zeros(numel(gaborBank), 1);
parfor j = 1 : numImagesToUse
%for j = 1 : numel(imagesCell)
    %get id of current worker
    t = getCurrentTask();
    %display progress
    if mod(j, stepPrint) == 0
        fprintf(1, ['\t\tCore ' num2str(t.ID) ': ' num2str(j) ' / ' num2str(numImagesToUse) '\n'])
    end %if mod(i, 100) == 0
    %get img
    im = imagesCell{j};
    %--------------------------------------
    %Perform reference Gabor filtering
    %fprintf_pers(fidLogs, '\t\tPerforming reference Gabor filtering... \n')
    resF= referenceGaborFilter(gaborBank, im);
    %--------------------------------------
    %create powerMap for all filters
    %fprintf_pers(fidLogs, '\t\tComputing powermaps... \n')
    powerMapF = computePowerMaps(resF, gaborBank);
    %--------------------------------------
    %Sort filter response information
    %fprintf_pers(fidLogs, '\t\tSorting filter response information... \n')
    [sortRes, sizeRes] = sortFilterResponse(gaborBank, powerMapF);
    %--------------------------------------
    %Compute most used wavelets
    %fprintf_pers(fidLogs, '\t\t\tComputing most used wavelets... \n')
    o_counter = getMostUsedWavelets(sortRes, gaborBank, powerMapF, param, sizeRes, plotta);
    %increment
    o_counterAll = o_counterAll + o_counter;
end %for j = 1 : length(vectorIndexTest)
o_counterAll_3=o_counterAll;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gaborBank=gaborBank_4;
o_counterAll = zeros(numel(gaborBank), 1);
parfor j = 1 : numImagesToUse
%for j = 1 : numel(imagesCell)
    %get id of current worker
    t = getCurrentTask();
    %display progress
    if mod(j, stepPrint) == 0
        fprintf(1, ['\t\tCore ' num2str(t.ID) ': ' num2str(j) ' / ' num2str(numImagesToUse) '\n'])
    end %if mod(i, 100) == 0
    %get img
    im = imagesCell{j};
    %--------------------------------------
    %Perform reference Gabor filtering
    %fprintf_pers(fidLogs, '\t\tPerforming reference Gabor filtering... \n')
    resF= referenceGaborFilter(gaborBank, im);
    %--------------------------------------
    %create powerMap for all filters
    %fprintf_pers(fidLogs, '\t\tComputing powermaps... \n')
    powerMapF = computePowerMaps(resF, gaborBank);
    %--------------------------------------
    %Sort filter response information
    %fprintf_pers(fidLogs, '\t\tSorting filter response information... \n')
    [sortRes, sizeRes] = sortFilterResponse(gaborBank, powerMapF);
    %--------------------------------------
    %Compute most used wavelets
    %fprintf_pers(fidLogs, '\t\t\tComputing most used wavelets... \n')
    o_counter = getMostUsedWavelets(sortRes, gaborBank, powerMapF, param, sizeRes, plotta);
    %increment
    o_counterAll = o_counterAll + o_counter;
end %for j = 1 : length(vectorIndexTest)
o_counterAll_4=o_counterAll;


%display most used filters
if plotta
    figure,
    bar(1:size(o_counterAll_1), o_counterAll_1)
    xlabel('Wavelet n.')
    ylabel('Perc. of occurence')
    title('Most used wavelets');
end %if plotta
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if plotta
    figure,
    bar(1:size(o_counterAll_2), o_counterAll_2)
    xlabel('Wavelet n.')
    ylabel('Perc. of occurence')
    title('Most used wavelets');
end %if plotta
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if plotta
    figure,
    bar(1:size(o_counterAll_3), o_counterAll_3)
    xlabel('Wavelet n.')
    ylabel('Perc. of occurence')
    title('Most used wavelets');
end %if plotta
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if plotta
    figure,
    bar(1:size(o_counterAll_4), o_counterAll_4)
    xlabel('Wavelet n.')
    ylabel('Perc. of occurence')
    title('Most used wavelets');
end %if plotta
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------------------------------

%sort most used filters counter
pyramid=[8 4 2 1]%每一个尺度选择的方向数
countfilter = 1;
[~, ind_o_counter_All_sort] = sort(o_counterAll_1, 'descend');
ind_o_counter_All_sort = ind_o_counter_All_sort(1 : pyramid(1));
bestWavelets = gaborBank_1(ind_o_counter_All_sort);
figure
for o = 1 : numel(bestWavelets)
    bestWaveletsAll(countfilter).filter = bestWavelets(o).filter;
    subplot(1,8,o),imshow(fftshift(bestWavelets(o).filter));
    countfilter = countfilter + 1;
end %for o
%%%%%%%%%%%%%%%%%%%
[~, ind_o_counter_All_sort] = sort(o_counterAll_2, 'descend');
ind_o_counter_All_sort = ind_o_counter_All_sort(1 : pyramid(2));
bestWavelets = gaborBank_2(ind_o_counter_All_sort);
figure
for o = 1 : numel(bestWavelets)
    bestWaveletsAll(countfilter).filter = bestWavelets(o).filter;
    subplot(1,4,o),imshow(fftshift(bestWavelets(o).filter));
    countfilter = countfilter + 1;
end %for o
%%%%%%%%%%%%%%%%%%%%%%%%%%
[~, ind_o_counter_All_sort] = sort(o_counterAll_3, 'descend');
ind_o_counter_All_sort = ind_o_counter_All_sort(1 : pyramid(3));
bestWavelets = gaborBank_3(ind_o_counter_All_sort);
figure
for o = 1 : numel(bestWavelets)
    bestWaveletsAll(countfilter).filter = bestWavelets(o).filter;
    subplot(1,4,o),imshow(fftshift(bestWavelets(o).filter));
    countfilter = countfilter + 1;
end %for o
%%%%%%%%%%%%%%%%%%%%%%%%%%%
[~, ind_o_counter_All_sort] = sort(o_counterAll_4, 'descend');
ind_o_counter_All_sort = ind_o_counter_All_sort(1 : pyramid(4));
bestWavelets = gaborBank_4(ind_o_counter_All_sort);
figure
for o = 1 : numel(bestWavelets)
    bestWaveletsAll(countfilter).filter = bestWavelets(o).filter;
    subplot(1,4,o),imshow(fftshift(bestWavelets(o).filter));
    countfilter = countfilter + 1;
end %for o
%%%%%%%%%%%%%%%%%%%%%%%%

PalmNet.NumFilters(end) = numel(bestWaveletsAll);
