function gabor = gaborArrayParametrized( orient_chosen)

rows=32;
cols=32;
nscale          = 4;   
norient         = length(orient_chosen);
minWaveLength   = 3; 
%mult            = 2.1;
mult=1.5;
sigmaOnf        = 0.55; %0.55:a bandwidth of roughly 2*octaves,0.75:bandwidth of approximatley 1 octave
dThetaOnSigma   = 1.5;
thetaSigma = pi/norient/dThetaOnSigma;
Lnorm=0;
feedback =1;
zero = zeros(rows,cols);
if mod(cols,2)
        xrange = [-(cols-1)/2:(cols-1)/2]/(cols-1);
    else
        xrange = [-cols/2:(cols/2-1)]/cols; 
    end
    
    if mod(rows,2)
        yrange = [-(rows-1)/2:(rows-1)/2]/(rows-1);
    else
        yrange = [-rows/2:(rows/2-1)]/rows; 
    end
    
    [x,y] = meshgrid(xrange, yrange);
    
    radius = sqrt(x.^2 + y.^2);       % Matrix values contain *normalised* radius from centre.
    theta = atan2(y,x);               % Matrix values contain polar angle.
                                  
    radius = ifftshift(radius);       % Quadrant shift radius and theta so that filters
    theta  = ifftshift(theta);        % are constructed with 0 frequency at the corners.
    radius(1,1) = 1;                  % Get rid of the 0 radius value at the 0
                                      % frequency point (now at top-left corner)
                                      % so that taking the log of the radius will 
                                      % not cause trouble.
    sintheta = sin(theta);
    costheta = cos(theta);
    clear x; clear y; clear theta;    % save a little memory
    
   
    lp = lowpassfilter([rows,cols],.45,15);   % Radius .45, 'sharpness' 15

    logGabor = cell(1,nscale);

    for s = 1:nscale
        wavelength = minWaveLength*mult^(s-1);
        fo = 1.0/wavelength;                  % Centre frequency of filter.
        logGabor{s} = exp((-(log(radius/fo)).^2) / (2 * log(sigmaOnf)^2));  
        logGabor{s} = logGabor{s}.*lp;        % Apply low-pass filter
        logGabor{s}(1,1) = 0;                 % Set the value at the 0
                                              % frequency point of the filter 
                                              % back to zero (undo the radius fudge). 
    end
    spread = cell(1,norient);
      % The main loop...
  for o = 1:norient
     angl =orient_chosen(o);           % Filter angle.
     ds = sintheta * cos(angl) - costheta * sin(angl);    % Difference in sine.
     dc = costheta * cos(angl) + sintheta * sin(angl);    % Difference in cosine.
     dtheta = abs(atan2(ds,dc));                          % Absolute angular distance.
      spread{o} = exp((-dtheta.^2) / (2 * thetaSigma^2));  % Calculate the
                                                       % angular filter component.
  end

  for o = 1:norient                    % For each orientation.
%  fprintf('Processing orientation %d\r',o);

  angl = orient_chosen(o);           % Filter angle.
  sumE_ThisOrient   = zero;          % Initialize accumulator matrices.
  sumO_ThisOrient   = zero;
  sumAn_ThisOrient  = zero;
  Energy            = zero;

  for s = 1:nscale,                  % For each scale.
    filter = logGabor{s} .* spread{o};   % Multiply radial and angular
                                         % components to get the filter.
    log_filters{s,o}=filter;
  end
  end
  
    for i = 1:norient    
            gabor(i).filter=log_filters{1,i};
    end
    %figure,montage(log_filters)


