% General parameters
param.numIterations = 1;
param.kfold = 2; % k-1 partition used for training; 1 partitions for testing

% KNN classifier parameters
param.knn_neighbors = 1;
param.matchDistance = 'euclidean';
param.knnDistance = 'euclidean';
param.numScoreAggregate = 4;
param.useDynamicNumFilters = 0;
param.RetainedVariance = [0.89 0.94];

% Parameters orientation search
param.numBins = 45;
param.divTheta = 10; % orientation
param.maxOrient = 6; % best orient kept

% Parameters Gabor from scales
param.N = 1; % sampling points per octave
param.b0 = 1; % the unit spatial interval
param.phai = 1.5; % band width of gabor [octave]
param.aspectRatio = 1;  % aspect ratio of the gabor filter

% Parameters Gabor parametrized
param.divThetaParametrized = param.divTheta;
param.sigma = 5.6179; %used for generating Gabor filter
param.wavelength = 0.11; %used for generating Gabor filter

% Parameters wavelet add
param.numWavelets = 10000;
param.minMSE = 0.005;
param.minCountW = 2000;
param.numBestWavelets = 18;

% PCANet parameters
LogGaborNet.NumStages = 2; %2
LogGaborNet.PatchSize = [15, 15]; %(default  [5 5]) ([15 15] seems good for iitd)
LogGaborNet.NumFilters = [(param.divThetaParametrized + param.numBestWavelets), (param.divThetaParametrized + param.numBestWavelets)]; % (default [8 8]) ([10 10] seems good for iitd)
LogGaborNet.HistBlockSize = [23, 23]; %(default 15 15) ([23 23] seems good for iitd)
LogGaborNet.BlkOverLapRatio = 0;
LogGaborNet.Pyramid = [];