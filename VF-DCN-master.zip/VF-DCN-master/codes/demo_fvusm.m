%% Demo of VF-DCN model for Finger Vein Recognition by using FVUSM dataset.


close all;
clear;
clc;


addpath(genpath('./functions_DBProc'));
addpath(genpath('./functions_Biometrics'));
addpath(genpath('./functions_Classifiers'));
addpath(genpath('./histogram_distance'));
addpath(genpath('./functions_Kovesi'));
addpath(genpath('./functions_Gabor'));
addpath(genpath('./functions_Orient'));
addpath(genpath('./functions_Freq'));
addpath(genpath('./functions_FeatExtr'));
addpath(genpath('./util'));


%% Parameters Setting

% General Params
plot = 1; % plot figures
savefile = 1; % saves data
logS = 1; % output logs
fidLogs{1} = 1; % stdoutput

numCoresFeatExtr = 5; % number of cores used for feature extraction
numCoresKnn = 5; % number of cores used for knn classification
stepPrint = 100;

% Network Params
run('./paramsLogGaborNet.m'); % parameter file


%% Load FV dataset

% Directory of DBs
ext = 'jpg'; %extension of images
dbname ='fvusm_original_roi_100_300_all';
dbresults = 'fvusm_original_roi_312';
dirDB = ['../images/' dbname '/'];

% RESULTS: dirs net
dirResults = ['./Results/' dbresults '/'];
mkdir_pers(dirResults, savefile);
fileSaveTest = [dirResults 'fvusm_original_roi_312_test.mat'];
fileSaveResults = [dirResults 'fvusm_original_roi_312_results.mat'];

% RESULTS: log file
timeStampRaw = datestr(datetime);
timeStamp = strrep(timeStampRaw, ':', '-');
if savefile && logS
    logFile = [dirResults dbname '_log_' timeStamp '.txt'];
    fidLog = fopen(logFile, 'w');
    fidLogs{2} = fidLog;
end


%% Dataset split

% Extract samples
files = dir([dirDB '*.' ext]);
% Compute labels
[labels, numImagesAll]= computeLabels_builtin_roi_fvusm(dirDB);
% Compute number of individuals
numInd = numel(unique(labels));
 
% Compute random person-fold indexes
% [indexesFold, allIndexes, indImagesTrain, indImagesTest, numImagesTrain, numImagesTest] ...
%     = computeIndexesPersonFold(numImagesAll, labels, param);


%% save dataset split
% eval(sprintf('save fvusm_trte_split.mat indexesFold;')); 
% eval(sprintf('save fvusm_trte_split.mat allIndexes -append;')); 
% eval(sprintf('save fvusm_trte_split.mat indImagesTrain -append;')); 
% eval(sprintf('save fvusm_trte_split.mat indImagesTest -append;')); 
% eval(sprintf('save fvusm_trte_split.mat numImagesTrain -append;')); 
% eval(sprintf('save fvusm_trte_split.mat numImagesTest -append;')); 

load fvusm_trte_split.mat;

% Corresponding labels
TrnLabels = labels(indImagesTrain);
TestLabels = labels(indImagesTest);    




%%%%%%%%%%%%%%  Adaptive Orientational Filters Selection  %%%%%%%%%%%%%%

imageSize = [32 32];

start_pool(numCoresFeatExtr);

% Load Training set images
fprintf_pers(fidLogs, '\t\tLoading images for training... \n');
[imagesCellTrain, filenameTrn] = loadImages(files, dirDB, allIndexes, indImagesTrain, numImagesTrain, plot); 
% Adjusting format
fprintf_pers(fidLogs, '\t\tAdjusting format...\n');
[imagesCellTrain, imageSize] = adjustFormat(imagesCellTrain, imageSize);

    
% Default orientations by sampling
orient_default = 0 : (180/param.divTheta) : 180-(180/param.divTheta);
nscale = 4;


% Compute parametrized LogGabor filters
imagesCell = imagesCellTrain;
plotta = plot;
numImagesToUse = numImagesTrain;
im = imagesCell{1};

log_filters = LogGabor(imageSize, deg2rad(orient_default), nscale);

% init counter for how many times each filter is chosen
o_counterAll = zeros(numel(orient_default), 1);

for s = 1 : nscale
    gaborBank = log_filters(s, :);
    parfor j = 1 : numImagesToUse
    % for j = 1 : numImagesToUse        
        t = getCurrentTask(); % get id of current worker
        % display progress
        if mod(j, stepPrint) == 0
            fprintf(1, ['\t\tCore ' num2str(t.ID) ': ' num2str(j) ' / ' num2str(numImagesToUse) '\n'])
        end
        
        im = imagesCell{j};
    
        % Perform LogGabor filtering
        resF = referenceGaborFilter(gaborBank, im);
    
        % create powerMap for all filters
        powerMapF = computePowerMaps(resF, gaborBank);
    
        % Sort filter response information
        [sortRes, sizeRes] = sortFilterResponse(gaborBank, powerMapF);
    
        % Compute most used wavelets
        o_counter = getMostUsedWavelets(sortRes, gaborBank, powerMapF, param, sizeRes, plotta);

        % increment
        o_counterAll = o_counterAll + o_counter;
    end

    o_counterAll_S{s} = o_counterAll;
end


% Display most used filters
if plotta
    for s = 1 : nscale
        figure,
        bar(1:numel(cell2mat(o_counterAll_S(1,s))), cell2mat(o_counterAll_S(1,s)));
        xlabel('LogGabor n.');
        ylabel('Perc. of occurence');
        title('Most used wavelets');
    end
end


% save results
% eval(sprintf('save train_fvusm.mat o_counterAll_S;'));  
% eval(sprintf('save train_fvusm.mat log_filters -append;')); 




%%%%%%%%%%%%%%  Best Filters Extraction  %%%%%%%%%%%%%%

% load train_fvusm.mat;

pyramid = [2  7  7  2]; % Num orientational filters within each scale

bestWaveletsAll(param.numBestWavelets).filter = [];


% Sort most used filters
countfilter = 1;

for s = 1 : nscale
    if pyramid(s) ~= 0
        o_counterAll_s = cell2mat(o_counterAll_S(1,s));
        [~, ind_o_counter_All_sort] = sort(o_counterAll_s, 'descend');
        ind_o_counter_All_sort = ind_o_counter_All_sort(1 : pyramid(s));
        bestWavelets = log_filters(s, ind_o_counter_All_sort);

        figure
        for o = 1 : numel(bestWavelets)
            bestWaveletsAll(countfilter).filter = bestWavelets{o};
            subplot(1,18,o), imshow(fftshift(bestWavelets{o}));
            countfilter = countfilter + 1;
        end
    end
end

LogGaborNet.NumFilters(end) = numel(bestWaveletsAll);


% save results
% eval(sprintf('save train_fvusm_pyramid.mat bestWaveletsAll;'));  




%%%%%%%%%%%%%%  Testing  %%%%%%%%%%%%%%

% load train_fvusm_pyramid.mat;

% Load Testing images
[imagesCellTest, filenameTest] = loadImages(files, dirDB, allIndexes, indImagesTest, numImagesTest, plot);
% Adjusting format
[imagesCellTest, imageSize] = adjustFormat(imagesCellTest, imageSize);

% Feature extraction
tic;
[ftest_all, numFeatures] = featExtrGaborAdapt(imagesCellTest, LogGaborNet, bestWaveletsAll, numImagesTest, stepPrint, numCoresFeatExtr);
sizeTest = size(ftest_all, 2);  
t = toc;
    
% save results
% eval(sprintf('save test_fvusm.mat TrnLabels;'));  
% eval(sprintf('save test_fvusm.mat TestLabels -append;')); 
% eval(sprintf('save test_fvusm.mat filenameTrn -append;')); 
% eval(sprintf('save test_fvusm.mat filenameTest -append;')); 
% eval(sprintf('save test_fvusm.mat ftest_all -append;')); 




%%%%%%%%%%%%%%  Verification Performance %%%%%%%%%%%%%%

r = 1;

% EER computation

fprintf_pers(fidLogs, '\tFPR and FNR computation\n');
    
tic;
[distMatrix, genuineInd, impostorInd, genuinesNorm, impostorsNorm, ...
    genuinesAggr, impostorsAggr, fprNorm, fnrNorm, fprAggr, fnrAggr,...
    EERNorm, EERAggr, FMR1000Norm, FMR1000Aggr] = ...
    computeVerificationPerformance(numImagesTest, ftest_all, filenameTest, stepPrint, param);
 
genuinesNorm_iter{r} = genuinesNorm;
impostorsNorm_iter{r} = impostorsNorm;
fprNorm_iter{r} = fprNorm;
fnrNorm_iter{r} = fnrNorm;
genuinesAggr_iter{r} = genuinesAggr;
impostorsAggr_iter{r} = impostorsAggr;
fprAggr_iter{r} = fprAggr;
fnrAggr_iter{r} = fnrAggr;
EERNormIter(r) = EERNorm;
EERAggrIter(r) = EERAggr;
FMR1000NormIter(r) = FMR1000Norm;
FMR1000AggrIter(r) = FMR1000Aggr;
    
%Time for FPR FNR computation
timeFPRFNR = toc;
fprintf_pers(fidLogs, ['\t\tTime for FPR and FNR computation: ' num2str(timeFPRFNR) ' s\n']);
fprintf_pers(fidLogs, ['\t\tEER (aggregated over ' num2str(param.numScoreAggregate) ' scores) at iteration n. ' num2str(r) ': %s%%\n'], ...
    num2str(EERAggrIter(r)*100));
fprintf_pers(fidLogs, ['\t\tFMR1000 (aggregated over ' num2str(param.numScoreAggregate) ' scores) at iteration n. ' num2str(r) ': %s%%\n'], ...
    num2str(FMR1000AggrIter(r)*100));
    
clear genuines impostors genuinesAggr impostorsAggr;


% Classification performance of 1-NN classifier (Nearest Neighbor)
fprintf_pers(fidLogs, '\tClassification... \n');
fprintf_pers(fidLogs, ['\t\tNumber of features: ' num2str(numFeatures) '\n']);
fprintf_pers(fidLogs, ['\t\tNumber of samples: ' num2str(sizeTest) '\n']);

tic
TestOutput = computekNNClassificationPerformance(ftest_all, TestLabels, sizeTest, distMatrix, stepPrint, numCoresKnn, param);
timeClass = toc;

fprintf_pers(fidLogs, ['\t\tTime for classification: ' num2str(timeClass) ' s\n']);

% Confusion matrix
[C_knn,class_labels] = confusionmat(TestLabels, TestOutput);

% Error metrics
err_knn = getNumberMisclassifiedSamples(C_knn);
accuracy_knn = (sum(C_knn(:)) - err_knn) / sum(C_knn(:));
accuracy_knnAll(r) = accuracy_knn;

% Display
fprintf_pers(fidLogs, ...
    ['\t\tAccuracy (perc. of correctly classified samples, at iteration n. ' num2str(r) '): %s%%\n'], num2str(accuracy_knn*100));        

clear ftest_all;

fprintf_pers(fidLogs, '\n');